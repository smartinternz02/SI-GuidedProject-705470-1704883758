<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS_country_change_005</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>9cf53a6e-5cc0-4cca-a34e-b15fe655d316</testSuiteGuid>
   <testCaseLink>
      <guid>d3b70cc3-d605-4b4c-8a41-750efb6ca88f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Datadriven_testing/TC_country_change_005</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>990793ef-7ffb-4488-a859-218b9d50217d</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/country_change_testdata_005</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>990793ef-7ffb-4488-a859-218b9d50217d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>location</value>
         <variableId>54505f40-b9c1-401b-822b-908bdd7954d9</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
