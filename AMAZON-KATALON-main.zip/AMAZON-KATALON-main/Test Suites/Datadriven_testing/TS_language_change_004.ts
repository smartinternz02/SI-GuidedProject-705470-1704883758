<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS_language_change_004</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>f8456859-0640-4e11-8a68-d0943b6ba847</testSuiteGuid>
   <testCaseLink>
      <guid>cebfb772-f495-4f31-855f-845d67ba0d97</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Datadriven_testing/TC_language_change_004</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>48f69478-2d47-4155-8ab0-fda810fa4291</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/language_change_testdata_004</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>48f69478-2d47-4155-8ab0-fda810fa4291</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>language</value>
         <variableId>f03c3bb7-14db-493f-b026-600857b5c9f6</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
