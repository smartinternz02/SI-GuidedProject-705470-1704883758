<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS_Delivery_address_004</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c3b70b5d-0b9c-4df2-bc73-945bca80eea1</testSuiteGuid>
   <testCaseLink>
      <guid>a5189a49-2e89-4866-a42b-98b7cf330f64</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Datadriven_testing/TC_Delivery_address_003</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>2c90ebf1-f704-4984-9347-054c771bfdcd</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/deliveryaddress_testdata_003</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>2c90ebf1-f704-4984-9347-054c771bfdcd</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>pincode</value>
         <variableId>6ae8c366-9cb0-47d1-9c67-61a97476ae58</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
