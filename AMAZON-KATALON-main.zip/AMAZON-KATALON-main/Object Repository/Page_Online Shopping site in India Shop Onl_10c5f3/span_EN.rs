<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_EN</name>
   <tag></tag>
   <elementGuidId>16e53e7c-7068-4ebd-b6ef-671a003913ed</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='icp-nav-flyout']/span/span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.icp-nav-link-inner > span.nav-line-2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>454a3b28-8f3d-443a-b488-0d6c155c54ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-line-2</value>
      <webElementGuid>bafae97a-bc6c-48d5-9ebb-1fe626df7f95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
          EN
        
      </value>
      <webElementGuid>c6bc4101-1c2e-4f30-9fae-96ffb1068461</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-nav-flyout&quot;)/span[@class=&quot;icp-nav-link-inner&quot;]/span[@class=&quot;nav-line-2&quot;]</value>
      <webElementGuid>5a9693eb-a05a-416a-80d6-b300d8aac394</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='icp-nav-flyout']/span/span[2]</value>
      <webElementGuid>f8edf648-20cb-4788-a77f-a5f571809c8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span[2]</value>
      <webElementGuid>8ee2a620-c00e-4236-978b-57f87b10f235</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        
          EN
        
      ' or . = '
        
          EN
        
      ')]</value>
      <webElementGuid>e8e22166-de47-4908-b764-0cc15a222865</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
