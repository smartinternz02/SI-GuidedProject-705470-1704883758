<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Tamil</name>
   <tag></tag>
   <elementGuidId>a523b3f6-b530-42e9-ba36-30d61c4136b9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[4]/div/label/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>746b5a40-ab7e-4dc9-bec5-5b600544aadf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>dir</name>
      <type>Main</type>
      <value>ltr</value>
      <webElementGuid>96cac30b-b2be-4127-bce9-4e107e43cc58</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        தமிழ் -
        TA

        
            
                    
            

            
                
                    - மொழிபெயர்ப்பு
                
            
        
    </value>
      <webElementGuid>c80d7b29-21d5-4754-8204-9055b93182ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]/span[@class=&quot;a-label a-radio-label&quot;]/span[1]</value>
      <webElementGuid>ae9e45cd-96b6-4f3e-b17a-028002ec93e5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[4]/div/label/span/span</value>
      <webElementGuid>6301aafb-fa2c-4c2b-a6fd-957ab4a4d843</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/label/span/span</value>
      <webElementGuid>7dabab45-066b-48ce-94fd-5095a10d160e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        தமிழ் -
        TA

        
            
                    
            

            
                
                    - மொழிபெயர்ப்பு
                
            
        
    ' or . = '
        தமிழ் -
        TA

        
            
                    
            

            
                
                    - மொழிபெயர்ப்பு
                
            
        
    ')]</value>
      <webElementGuid>3bb0699b-89d8-4c83-981d-5f7b4b7dfeec</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
