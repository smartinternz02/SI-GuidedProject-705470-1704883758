<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>English</name>
   <tag></tag>
   <elementGuidId>427733a0-8e1b-49a5-8d56-5faa190039a7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[2]/div/label/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-label.a-radio-label > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7142cbdc-9152-4bb0-bf45-5adebde6c7bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>dir</name>
      <type>Main</type>
      <value>ltr</value>
      <webElementGuid>95ac23ea-d363-4c65-b30b-a5743fdbf373</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        English -
        EN

        
    </value>
      <webElementGuid>66146ce2-26e7-42ff-8709-774454173105</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]/span[@class=&quot;a-label a-radio-label&quot;]/span[1]</value>
      <webElementGuid>7e4b52f1-dd73-4bcf-b612-88525a19cdd1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[2]/div/label/span/span</value>
      <webElementGuid>638d683c-94f1-48de-a265-23adb94fbc5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label/span/span</value>
      <webElementGuid>1d003cfd-dbb7-4d8d-9c03-5f878165a120</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        English -
        EN

        
    ' or . = '
        English -
        EN

        
    ')]</value>
      <webElementGuid>e2e43022-3b2a-4ca9-b02f-4a47cb93765a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
