<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Malayalam</name>
   <tag></tag>
   <elementGuidId>f5b5bcc2-668d-4158-b5bc-2843f486e62a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[7]/div/label/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>1f554b8c-12f3-4d6d-8ca7-7ff3e94475bb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>dir</name>
      <type>Main</type>
      <value>ltr</value>
      <webElementGuid>d25f3ad8-374f-416c-bc96-c818a6533485</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        മലയാളം -
        ML

        
            
                    
            

            
                
                    - വിവർത്തനം
                
            
        
    </value>
      <webElementGuid>d893c46a-9267-470c-b89f-4d87b0234c81</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]/span[@class=&quot;a-label a-radio-label&quot;]/span[1]</value>
      <webElementGuid>1faea5ac-57eb-478e-bea9-5efa3f338288</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[7]/div/label/span/span</value>
      <webElementGuid>b1b7a4c4-8e0f-4052-a3d5-634fad157824</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/label/span/span</value>
      <webElementGuid>11464e3b-d00a-49e0-8bd6-be9df8b86bf7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        മലയാളം -
        ML

        
            
                    
            

            
                
                    - വിവർത്തനം
                
            
        
    ' or . = '
        മലയാളം -
        ML

        
            
                    
            

            
                
                    - വിവർത്തനം
                
            
        
    ')]</value>
      <webElementGuid>450f9fc9-fa01-4fa6-b3ea-44f41b065048</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
