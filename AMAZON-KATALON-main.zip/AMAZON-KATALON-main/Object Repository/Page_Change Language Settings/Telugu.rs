<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Telugu</name>
   <tag></tag>
   <elementGuidId>e3bead1e-071b-4767-8513-2f6f1a67cf9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='icp-language-settings']/div[5]/div/label/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>2171c7f6-3e43-4e14-919e-dde6c24df989</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>dir</name>
      <type>Main</type>
      <value>ltr</value>
      <webElementGuid>26599420-1df4-46cc-b622-8e504fa274cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        తెలుగు -
        TE

        
            
                    
            

            
                
                    - అనువాదం
                
            
        
    </value>
      <webElementGuid>0e106501-72ae-4eb6-bfe8-a5cbc22a96ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-language-settings&quot;)/div[@class=&quot;a-row a-spacing-mini&quot;]/div[@class=&quot;a-radio a-radio-fancy&quot;]/label[1]/span[@class=&quot;a-label a-radio-label&quot;]/span[1]</value>
      <webElementGuid>23e1b71c-56c1-4648-99e6-b4501901df69</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='icp-language-settings']/div[5]/div/label/span/span</value>
      <webElementGuid>b2639f15-effe-4f3b-b062-09b8f1aa91e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/label/span/span</value>
      <webElementGuid>65c49123-2f33-4a17-ac98-280385525420</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        తెలుగు -
        TE

        
            
                    
            

            
                
                    - అనువాదం
                
            
        
    ' or . = '
        తెలుగు -
        TE

        
            
                    
            

            
                
                    - అనువాదం
                
            
        
    ')]</value>
      <webElementGuid>ba1c9abf-7b9d-4570-9d2a-ce10234b1080</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
